const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const socketIo = require('socket.io');
const http = require('http');
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Konfigurasi database MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // Ganti dengan password MySQL Anda
  database: 'kapal_db',
});

db.connect((err) => {
  if (err) throw err;
  console.log('Database connected...');
});

// Middleware
app.use(bodyParser.json());

// Secret key untuk JWT
const JWT_SECRET = 'your_jwt_secret_key';

// Auth middleware
const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];
  if (!token) return res.status(403).json({ message: 'Access Denied' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
};

// Socket.io untuk notifikasi real-time
io.on('connection', (socket) => {
  console.log('A user connected');
  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

// Endpoint untuk registrasi user baru
app.post('/register', (req, res) => {
  const { username, password, role } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  const sql = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
  db.query(sql, [username, hashedPassword, role], (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    res.status(201).json({ message: 'Registered successfully' });
  });
});

// Endpoint untuk login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const sql = 'SELECT * FROM users WHERE username = ?';
  db.query(sql, [username], (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    if (result.length === 0) return res.status(404).json({ message: 'User not found' });

    const user = result[0];
    if (bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ id_user: user.id_user, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
      res.json({ message: 'Login successful', token });
      io.emit('notification', `User ${username} logged in.`);
    } else {
      res.status(400).json({ message: 'Invalid password' });
    }
  });
});

// Endpoint untuk melihat data kapal
app.get('/kapal', authenticateJWT, (req, res) => {
  const sql = 'SELECT * FROM kapal';
  db.query(sql, (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    res.json(result);
  });
});

// Endpoint untuk menambah data kapal (admin only)
app.post('/kapal', authenticateJWT, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Access Denied' });

  const { nama_kapal, jenis_kapal, kapasitas_muatan } = req.body;
  const sql = 'INSERT INTO kapal (nama_kapal, jenis_kapal, kapasitas_muatan) VALUES (?, ?, ?)';
  db.query(sql, [nama_kapal, jenis_kapal, kapasitas_muatan], (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    res.json({ message: 'Kapal added successfully' });
    io.emit('notification', 'New kapal added.');
  });
});

// Endpoint untuk mengupdate data kapal (admin only)
app.put('/kapal/:id_kapal', authenticateJWT, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Access Denied' });

  const { id_kapal } = req.params;
  const { nama_kapal, jenis_kapal, kapasitas_muatan } = req.body;
  const sql = 'UPDATE kapal SET nama_kapal = ?, jenis_kapal = ?, kapasitas_muatan = ? WHERE id_kapal = ?';
  db.query(sql, [nama_kapal, jenis_kapal, kapasitas_muatan, id_kapal], (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    res.json({ message: 'Kapal updated successfully' });
    io.emit('notification', 'Kapal updated.');
  });
});

// Endpoint untuk menghapus data kapal (admin only)
app.delete('/kapal/:id_kapal', authenticateJWT, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Access Denied' });

  const { id_kapal } = req.params;
  const sql = 'DELETE FROM kapal WHERE id_kapal = ?';
  db.query(sql, [id_kapal], (err, result) => {
    if (err) return res.status(500).json({ message: err.message });
    res.json({ message: 'Kapal deleted successfully' });
    io.emit('notification', 'Kapal deleted.');
  });
});

// Menjalankan server
server.listen(678, () => {
  console.log('Server running on port 678');
});
